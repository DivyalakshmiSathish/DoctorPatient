import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import { AuthServiceService } from '../auth-service.service';
import {Router}  from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  formGroup: FormGroup;
  constructor(private authService:AuthServiceService,
    private readonly _router: Router) { }

  ngOnInit() {
    this.initForm();
  }
  initForm()
  {
    this.formGroup= new FormGroup(
    {
      UserName: new FormControl(''),
      Password: new FormControl('')
    });
  }
  login()
  {
    if(this.formGroup.valid){
      this.authService.login(this.formGroup.value).subscribe(results=>{
          this._router.navigate(['home']);
      })
    }
  }

}
