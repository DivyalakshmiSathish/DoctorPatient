import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import { RegisterServiceService } from '../register-service.service';
import {Router}  from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  formGroup: FormGroup;
  alert:boolean=false
  constructor(private registerService:RegisterServiceService,
    private readonly _router: Router) { }

  ngOnInit(): void {
    this.initForm();
  }
  initForm()
  {
    this.formGroup= new FormGroup(
    {
      Name: new FormControl(''),
      Gender: new FormControl(''),
      Phone: new FormControl(''),
      MailId: new FormControl(''),
      Password: new FormControl(''),
      ConfirmPassword: new FormControl(''),
      UserRole:new FormControl('')
    });
  }
  register()
  {
    if(this.formGroup.valid){
      this.registerService.register(this.formGroup.value).subscribe(results=>{
          console.log(this.formGroup.value);
      })
    }
  }

}
