﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using VisitDoctor.Authentication;


using VisitDoctor.Models;
using VisitDoctor.Models.Request;
using VisitDoctor.Repository;

namespace VisitDoctor.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorPatientController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IDoctorPatientQueryService _doctorPatientQueryService;
        private readonly IConfiguration _configuration;

        public DoctorPatientController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration,IDoctorPatientQueryService doctorPatientQueryService)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _configuration = configuration;
            _doctorPatientQueryService = doctorPatientQueryService;
        }

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Register([FromBody] LoginModel login)
        {
            var user = await _userManager.FindByNameAsync(login.UserName);
            if (user != null && await _userManager.CheckPasswordAsync(user, login.Password))
            {
                var userRoles = await _userManager.GetRolesAsync(user);
                var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name,user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };
                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }

                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));

                var token = new JwtSecurityToken(
                    issuer: _configuration["JWT:ValidIssuer"],
                    audience: _configuration["JWT:ValidAudience"],
                    expires: DateTime.Now.AddHours(3),
                    claims: authClaims,
                    signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                );
                return Ok(new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(token),
                    expiration = token.ValidTo,
                    User = user.UserName
                });
            }
            return Unauthorized();
                
        }
        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            var userExists = await _userManager.FindByNameAsync(user.Name);
            if (userExists != null)

            { return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already Exists" }); }
            ApplicationUser appuser = new ApplicationUser()
            {
                Email = user.MailId,
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = user.Name
            };

            var result = await _userManager.CreateAsync(appuser, user.Password);
            if (!result.Succeeded)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already Exists" });
            }

            return Ok(new Response { Status = "Success", Message = "User created successfully" });
        }

        [HttpGet]
        [Route("DoctorsAvailable")]
        public async Task<IActionResult> GetDoctorsAvailable()
        {
            var result = await _doctorPatientQueryService.GetAvailableDoctosAsync();
            return Ok(result);
            
        }

        [HttpPost]
        [Route("PatientBookAppointment")]
        public async Task<IActionResult> PatientBookAppointment(BookAppointment book)
        {
            var result = await _doctorPatientQueryService.PatientBookAppointmentAsync(book);
            return Ok(result);

        }

           }
}