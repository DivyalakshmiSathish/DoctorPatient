﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VisitDoctor.Authentication;
using VisitDoctor.Models;
using VisitDoctor.Models.Request;
using VisitDoctor.Models.Response;

namespace VisitDoctor.Repository
{
    public class DoctorPatientQueryService: IDoctorPatientQueryService
    {
        private readonly ApplicationDbContext _dbContext;
        public DoctorPatientQueryService(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<AvailableDoctorModel>> GetAvailableDoctosAsync()
        {
            var result = from user in _dbContext.Set<User>().Where(x => x.UserRole == "Doctor")
                select new AvailableDoctorModel(user);
            return await Task.FromResult(result.ToList());
        }

        public async Task<List<AppointmentModel>> PatientBookAppointmentAsync(BookAppointment book)
        {
            var result = from user in _dbContext.Set<User>().Where(x => x.Id== book.DoctorId && x.Name== book.DoctorName && x.Id== book.PatientId && x.Name== book.PatientName)
                         select new AppointmentModel(user);
            return await Task.FromResult(result.ToList());
        }
    }
}
