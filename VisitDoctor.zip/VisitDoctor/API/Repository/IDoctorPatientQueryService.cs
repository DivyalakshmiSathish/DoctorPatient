﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VisitDoctor.Models.Request;
using VisitDoctor.Models.Response;

namespace VisitDoctor.Repository
{

    public interface IDoctorPatientQueryService
    {
        Task<List<AvailableDoctorModel>> GetAvailableDoctosAsync();
        Task<List<AppointmentModel>> PatientBookAppointmentAsync(BookAppointment book);
    }
}
