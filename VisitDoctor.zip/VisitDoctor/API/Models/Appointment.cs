﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VisitDoctor.EntityFramework
{
    public class Appointment
    {
        [Column("Id")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public int AppointmentNumber { get; set; }

        [ForeignKey("DoctorId")]
        [Required]
        public int DoctorId { get; set; }

        [ForeignKey("DoctorName")]
        [Required]
        [StringLength(50)]
        public string DoctorName { get; set; }

        [ForeignKey("PatientId")]
        [Required]
        public int PatientId { get; set; }

        [ForeignKey("PatientName")]
        [Required]
        [StringLength(50)]
        public string PatientName { get; set; }

        [Column("Appointment_Date")]
        public DateTime Appointment_Date { get; set; }

        [Column("Appointment_Time")]
        public DateTime Appointment_Time{ get; set; }

    }
}
