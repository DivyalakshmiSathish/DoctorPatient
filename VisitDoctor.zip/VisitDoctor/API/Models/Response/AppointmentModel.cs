﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VisitDoctor.Authentication;

namespace VisitDoctor.Models.Response
{
    public class AppointmentModel
    {
        public int DoctorId { get; set; }
        public int PatientId { get; set; }
        public string DoctorName { get; set; }

        public string PatientName { get; set; }

        public AppointmentModel(User user)
        {
            DoctorId = user.Id;
            PatientId = user.Id;
            DoctorName = user.Name;
            PatientName = user.Name;
        }
    }
}
