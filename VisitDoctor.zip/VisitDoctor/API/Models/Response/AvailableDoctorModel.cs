﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VisitDoctor.Authentication;

namespace VisitDoctor.Models.Response
{
    public class AvailableDoctorModel
    {
        public string DoctorName { get; set; }

        public AvailableDoctorModel(User user)
        {
            DoctorName = user.Name;
        }
    }
}
