﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VisitDoctor.Authentication
{
    public class User
    {
        [Column("UserId")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public int Id { get; set; }

        [Column("UserName")]
        [Required(ErrorMessage ="Please enter Name")]
        [Display(Name="User Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Column("Gender")]
        [Required(ErrorMessage ="Please select a gender")]
        [Display(Name = "Gender")]
        [StringLength(50)]
        public string Gender { get; set; }

        [Column("Phone")]
        [Required(ErrorMessage = "Please enter a 10 digit number")]
        [Display(Name = "Phone")]
        public long Mobile { get; set; }

        [Column("MailId")]
        [Required(ErrorMessage = "Please enter a valid emailid")]
        [Display(Name = "Email")]
        [StringLength(50)]
        public string MailId { get; set; }

        [Column("Password")]
        [Required(ErrorMessage = "Please enter a password")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        [StringLength(20)]
        public string Password { get; set; }

        [Column("ConfirmPassword")]
        [Required(ErrorMessage = "Please re-enter password")]
        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("Password")]
        [StringLength(20)]
        public string ConfirmPassword { get; set; }

        [Column("UserRole")]
        [Required]
        [Display(Name = "User Role")]
        [StringLength(20)]
        public string UserRole { get; set; }

    }
}
