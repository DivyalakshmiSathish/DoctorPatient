﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VisitDoctor.Authentication
{
    public class UserRole
    {
        [ForeignKey("UserId")]
        [Key]
        [Required]
        public int Id { get; set; }

        [Column("UserRole")]
        [Required]
        [StringLength(50)]
        public string Role { get; set; }

        
    }
}
